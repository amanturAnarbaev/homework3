package com.company;

import java.util.Arrays;

public class Main {
   static int b=0;
   static double ans=0;
   static int q=0;
    public static void main(String[] args) {
        double[] m = {1.5, 0.9, -6.8, 5.6,2.6,3.9,-6.9,5.6,9.6,5.9,-5.9,5.5,7.2,1.0,2.6};
        double avNum = 0;
        for (int i = 0; i <m.length ; i++) {
            for (double a:m
            ) { if (m[i] < 0) {
                    b = i;
                    break;
                }
            }
            }
        for (int j = b; j <m.length ; j++) {
            if (m[j]<0){
                continue; }
            
            ans= ans +m[j];
            q=q+1;
        }
        System.out.println("the answer is    " +ans/q);
        System.out.println("bye bye");
        }



    }
















